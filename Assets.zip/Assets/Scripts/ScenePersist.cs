using UnityEngine;

public class ScenePersist : MonoBehaviour
{
    void Awake()
    {
        // ScenePersist 타입으로 중복 여부 확인
        ScenePersist existingScenePersist = FindAnyObjectByType<ScenePersist>();
        if (existingScenePersist != this)
        {
            Destroy(gameObject);
        }
        else
        {
            DontDestroyOnLoad(gameObject);
        }
    }
    
    public void ResetScenePersist()
    {
        Destroy(gameObject);
    }
}
