using System;
using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LevelExit : MonoBehaviour
{
    [SerializeField] float levelLoadDelay;

    void OnTriggerEnter2D(Collider2D other)
    {
        if(other.tag == "Player")
        {
            StartCoroutine(LoadNextlevel());
        }

    }

    IEnumerator LoadNextlevel()
        {
            yield return new WaitForSecondsRealtime(levelLoadDelay);
            int CurrentSceneIndex = SceneManager.GetActiveScene().buildIndex;
            int nextSceneIndex = CurrentSceneIndex + 1;

            if(nextSceneIndex == SceneManager.sceneCountInBuildSettings)
            {
                nextSceneIndex = 0;
            }

            FindAnyObjectByType<ScenePersist>().ResetScenePersist();
            SceneManager.LoadScene(nextSceneIndex);  
        }
}
