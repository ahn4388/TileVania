using System;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerMovement : MonoBehaviour
{
    [SerializeField] float runSpeed = 10f;
    [SerializeField] float jumpSpeed = 5f;
    [SerializeField] float climbSpeed = 5f;
    [SerializeField] Vector2 deathKick = new Vector2 (0f, 50f);
    [SerializeField] GameObject bullet;
    [SerializeField] Transform Gun;

    Vector2 moveInput;
    Rigidbody2D myRigidBody;
    Animator myAnimator;
    BoxCollider2D myBoxCollider2D;
    CapsuleCollider2D myCapsuleCollider2D;
    float gravityScaleAtStart;

    bool isAlive = true;

    void Start()
    {
        myRigidBody = GetComponent<Rigidbody2D>();
        myAnimator = GetComponent<Animator>();
        myBoxCollider2D = GetComponent<BoxCollider2D>();
        myCapsuleCollider2D = GetComponent<CapsuleCollider2D>();
        gravityScaleAtStart = myRigidBody.gravityScale;
    }

    void Update()
    {
        if(!isAlive){
            return;
        }
        Run();
        FlipSprite();
        ClimbLadder();
        Die();
    }

    void Die()
    {
        if (myBoxCollider2D.IsTouchingLayers(LayerMask.GetMask("Enemies", "Hazerds")))
        {
            isAlive = false;
            myAnimator.SetTrigger("Dying");
            myRigidBody.linearVelocity = deathKick;
            FindAnyObjectByType<GameSession>().ProcessPlayerDeath();
        }
    }

    void OnAttack(InputValue value)
    {
        if(isAlive){
            Instantiate(bullet, Gun.position, transform.rotation);
        }
    }

    void Run()
    {
        Vector2 playerVelocity = new Vector2(moveInput.x * runSpeed, myRigidBody.linearVelocity.y);
        myRigidBody.linearVelocity = playerVelocity;

        bool playerHasHorisontalSpeed = Mathf.Abs(myRigidBody.linearVelocityX) > Mathf.Epsilon;

        myAnimator.SetBool("IsRunning",playerHasHorisontalSpeed);

    }
    void OnJump(InputValue value)
    {
        if(!isAlive){
            return;
        }
        if(!myCapsuleCollider2D.IsTouchingLayers(LayerMask.GetMask("Ground")))
        {
            return;
        }
        if(value.isPressed)
        {
            myRigidBody.linearVelocity += new Vector2(0f, jumpSpeed);
        }
    }

    void OnMove(InputValue value){
        if(!isAlive){
            return;
        }
        moveInput = value.Get<Vector2>();
        Debug.Log(moveInput);
    }

    private void FlipSprite()
    {
        bool playerHasHorisontalSpeed = Mathf.Abs(myRigidBody.linearVelocity.x) > Mathf.Epsilon;
        if(playerHasHorisontalSpeed)
            {
            transform.localScale = new Vector2 (Mathf.Sign(myRigidBody.linearVelocity.x), 1f);
            }
    }

    void ClimbLadder()
    {
        if(!myCapsuleCollider2D.IsTouchingLayers(LayerMask.GetMask("Climbing")))
        {
            myAnimator.SetBool("IsCliming",false);
            myRigidBody.gravityScale = gravityScaleAtStart;
            return;
        }

        Vector2 climbVelocity = new Vector2(myRigidBody.linearVelocityX, moveInput.y * climbSpeed);
        myRigidBody.linearVelocity = climbVelocity;
        myRigidBody.gravityScale = 0f;
        
        bool playerVerticalSpeed = Mathf.Abs(myRigidBody.linearVelocityY) > Mathf.Epsilon;

        myAnimator.SetBool("IsCliming",playerVerticalSpeed);
    }
}
